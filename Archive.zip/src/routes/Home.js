import React from 'react';
import axios from 'axios';

useEffect(() => {

}, [])

const Home = ({ data: { loading, allUsers = [] } }) => {
    return(
        <div>

        </div>
    )
}

export default Home;
